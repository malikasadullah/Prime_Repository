package com.example

import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.utils.safelyParseJson
import org.jsoup.Jsoup

class RareToonsProvider : MainAPI() {
    override var mainUrl = "https://rareanimes.app/"
    override var name = "RareToons"
    override val supportedTypes = setOf(TvType.Series)
    override var lang = "en"
    override val hasMainPage = true

    // Search function
    override suspend fun search(query: String): List<SearchResponse> {
        val url = "$mainUrl/search/$query"
        val doc = Jsoup.connect(url).get()
        val results = mutableListOf<SearchResponse>()

        doc.select("div.item")?.forEach { element ->
            val title = element.selectFirst("h3.title")?.text() ?: return@forEach
            val link = element.selectFirst("a")?.attr("href") ?: return@forEach
            results.add(SearchResponse(title, link))
        }

        return results
    }

    // Main page (optional)
    override suspend fun mainPage(): List<SearchResponse> {
        val doc = Jsoup.connect(mainUrl).get()
        val results = mutableListOf<SearchResponse>()

        doc.select("div.item")?.forEach { element ->
            val title = element.selectFirst("h3.title")?.text() ?: return@forEach
            val link = element.selectFirst("a")?.attr("href") ?: return@forEach
            results.add(SearchResponse(title, link))
        }

        return results
    }

    // Video links extract
    override suspend fun loadLinks(url: String, isCasting: Boolean, subtitleCallback: (String, String) -> Unit): List<String> {
        val doc = Jsoup.connect(url).get()
        val links = mutableListOf<String>()
        doc.select("iframe").forEach { iframe ->
            val src = iframe.attr("src")
            if (src.contains("https")) {
                links.add(src)
            }
        }
        return links
    }
}