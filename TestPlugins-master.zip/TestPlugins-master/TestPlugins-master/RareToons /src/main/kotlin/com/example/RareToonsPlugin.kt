package com.example

import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.PluginBase

class RareToonsPlugin : PluginBase() {

    override val mainAPI: MainAPI = RareToonsProvider()

    override val pluginId: String = "raretoons_plugin"
    override val pluginName: String = "RareToons"
    override val pluginVersion: String = "1.0.0"
}